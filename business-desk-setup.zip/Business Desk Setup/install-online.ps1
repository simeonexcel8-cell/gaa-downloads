$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Host.UI.RawUI.WindowTitle = 'Install Business Desk'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Base = 'https://gaa-downloads.netlify.app/business-desk/parts/'
$Expected = '59731504CBF375DEB2DA8BA4034836D6BB200EDF53C89EF302CCF5E904691A31'
$Count = 10
$Work = Join-Path $env:TEMP 'BusinessDeskSetup'
try {
    Write-Host ''
    Write-Host '  Installing Business Desk 2.9' -ForegroundColor Green
    Write-Host '  Downloading about 185 MB. Keep this window open.'
    Write-Host ''
    if (Test-Path $Work) { Remove-Item $Work -Recurse -Force }
    New-Item -ItemType Directory -Path $Work -Force | Out-Null
    $Zip = Join-Path $Work 'setup.zip'
    $out = [System.IO.File]::Create($Zip)
    try {
        for ($i = 1; $i -le $Count; $i++) {
            $name = 'business-desk.zip.{0:D3}' -f $i
            $part = Join-Path $Work $name
            Write-Host ("  Downloading part {0} of {1}..." -f $i, $Count)
            $ok = $false
            for ($try = 1; $try -le 3 -and -not $ok; $try++) {
                try { Invoke-WebRequest -Uri ($Base + $name) -OutFile $part -UseBasicParsing; $ok = $true }
                catch { if ($try -eq 3) { throw "Couldn't download part $i. Check your internet connection and run the installer again." } ; Start-Sleep -Seconds 3 }
            }
            $in = [System.IO.File]::OpenRead($part)
            try { $in.CopyTo($out) } finally { $in.Close() }
            Remove-Item $part -Force
        }
    } finally { $out.Close() }
    Write-Host '  Checking the download...'
    $actual = (Get-FileHash -Path $Zip -Algorithm SHA256).Hash
    if ($actual -ne $Expected) { throw 'The download was damaged. Run the installer again.' }
    Write-Host '  Unpacking...'
    Expand-Archive -Path $Zip -DestinationPath $Work -Force
    Remove-Item $Zip -Force
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Work 'Business Desk Setup\setup\install.ps1')
    $code = $LASTEXITCODE
    Remove-Item $Work -Recurse -Force -ErrorAction SilentlyContinue
    exit $code
}
catch {
    Write-Host ''
    Write-Host ('  Setup did not finish: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host ''
    Remove-Item $Work -Recurse -Force -ErrorAction SilentlyContinue
    Read-Host '  Press Enter to close'
    exit 1
}
