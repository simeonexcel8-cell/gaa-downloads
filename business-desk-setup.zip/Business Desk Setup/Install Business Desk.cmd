@echo off
title Install Business Desk
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-online.ps1"
